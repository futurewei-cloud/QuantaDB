(defproject tutorial "0.1.0-SNAPSHOT"
  :main tutorial.core
  :dependencies [[org.clojure/clojure "1.5.1"]])